<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

use App\Models\Experiencia;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;

class ExperienciaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($page)
    {
        
        $limitePorPagina = 50;
        $experiencias = DB::table('experiencias')->offset(($page -1) * $limitePorPagina)->limit($limitePorPagina)->get();
         //$experiencias = Experiencia::all();
 
 
         return $experiencias;
 
    }

    public function experienciasByUsuario($page, $idUsuario) 
    {

        $limitePorPagina = 50;
        $experiencias = DB::table('experiencias')->where('user_id','=', $idUsuario)
                                                 ->offset(($page -1) * $limitePorPagina)->limit($limitePorPagina)
                                                 ->get();

 
         return $experiencias;



    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $experiencia = new Experiencia();
        $experiencia->titulo = $request->titulo;
        $experiencia->descripcion = $request->descripcion;
        $experiencia->valoracion = $request->valoracion;        
        $experiencia->imagen_experiencia = $request->filename;
        $experiencia->juguete_id = $request->juguete_id;
        $experiencia->user_id = $request->user_id;
        $experiencia->publicado = $request->publicado;

        $experiencia->save();
        
        if ($request->hasFile('thumbnail') && $request->file('thumbnail')->isValid()) {

            $uploaded_file = $request->file('thumbnail');
            //directorio 'Experiencias'
            $uploaded_file->move('Experiencias/'. $request->user_id . '/' . $experiencia->id , $request->filename);

        }

        return [
            'id' => $experiencia->id,
            'titulo' => $experiencia->titulo,
            'descripcion' => $experiencia->descripcion,
            'imagen_experiencia' => $experiencia->imagen_experiencia,
        ];


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $experiencia = Experiencia::find($id);
        return [

            'id' => $experiencia->id,
            'titulo' => $experiencia->titulo,
            'fecha_publicacion' => $experiencia->fecha_publicacion,
            'descripcion' => $experiencia->descripcion,
            'imagen_experiencia' => $experiencia->imagen_experiencia,
            'juguete_id' => $experiencia->juguete_id,
            'publicado' => $experiencia->publicado,
            'valoracion' => $experiencia->valoracion,
            'user_id' => $experiencia->user_id,

            ];

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }



    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    //public function update(Request $request, $id)
    public function update(Request $request)
    {
        
        $update = [
            "titulo" => $request->titulo,
            "descripcion" => $request->descripcion,
            "imagen_experiencia" => $request->filename,
            "publicado" => $request->publicado,
            "juguete_id" => $request->juguete_id,
            "user_id" => $request->user_id,
            "valoracion" => $request->valoracion
        ];

        Experiencia::where('id', $request->id)->update($update);

        if ($request->hasFile('thumbnail') && $request->file('thumbnail')->isValid()) {

            $uploaded_file = $request->file('thumbnail');
            //directorio 'Experiencias'
            $uploaded_file->move('Experiencias/'. $request->user_id . '/' . $request->id , $request->filename);

        }

        //Guardamos la imagen en el sistema de ficheros del sistema.
        return $update;

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        Experiencia::destroy($id);
        return true;
    }

    public function publicar($id) {

        $experiencia = Experiencia::findOrFail($id);
        $experiencia->publicado = 1;
        $experiencia->save();
        return true;

    }

    public function noPublicar($id) {

        $experiencia = Experiencia::findOrFail($id);
        $experiencia->publicado = 0;
        $experiencia->save();
        return true;
    }



}
